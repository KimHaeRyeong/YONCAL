package univ.yonsei.yoncal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YoncalApplication {

	public static void main(String[] args) {
		SpringApplication.run(YoncalApplication.class, args);
	}

}
