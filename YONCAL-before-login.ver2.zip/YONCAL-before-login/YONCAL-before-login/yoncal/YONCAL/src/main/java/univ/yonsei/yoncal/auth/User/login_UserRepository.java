// User entity에 대한 데이터베이스 작업을 수행하는 JPA 리포지토리 인터페이스
package com.yoncal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.yoncal.domain.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}
